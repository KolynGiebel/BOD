
# Go For Giebel Campaign Website

This is the official campaign website for Kolyn Giebel's Board of Directors candidacy.

## 🚀 How to Launch This Site

### 1. Upload to GitHub

- Create a new repo at https://github.com
- Upload all files from this project
- Push using `git` or GitHub Desktop

### 2. Deploy with Netlify

- Go to [https://netlify.com](https://netlify.com)
- Choose **New Site from Git**
- Connect your GitHub repo
- Use these settings:
  - **Build command:** `npm run build`
  - **Publish directory:** `build`

### 3. Set Custom Domain

Once deployed:
- In Netlify Dashboard → Domain Settings
- Add `GoForGiebel.com` (you may need to update DNS records)

### 📬 Contact

Email: Kolyn.Giebel@gmail.com
